
import { GoogleGenAI } from "@google/genai";
import type { UploadedFile } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

interface FilePart {
  inlineData: {
    mimeType: string;
    data: string;
  };
}

export const analyzeDocuments = async (question: string, files: UploadedFile[]): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const model = 'gemini-2.5-flash';

  const fileParts: FilePart[] = files.map(file => ({
    inlineData: {
      mimeType: file.type,
      data: file.content,
    }
  }));

  const systemInstruction = `You are a highly intelligent assistant specializing in document analysis.
  Your task is to answer questions based *exclusively* on the content of the provided documents and images.
  Be thorough and precise in your answers. If the answer cannot be found in the documents, state that clearly.
  Do not use any external knowledge. Structure your answers in clear, easy-to-read markdown format.`;
  
  const contents = {
      parts: [
          ...fileParts,
          { text: `Based on the provided documents, please answer the following question: ${question}` }
      ]
  };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text;
  } catch (error) {
    console.error('Gemini API Error:', error);
    throw new Error('Failed to communicate with the AI model. Please check your API key and network connection.');
  }
};
