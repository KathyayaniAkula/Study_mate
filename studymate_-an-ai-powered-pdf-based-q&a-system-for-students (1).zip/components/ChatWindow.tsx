
import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage } from '../types';
import { MessageSender } from '../types';
import { SendIcon, BrainCircuitIcon, UserIcon } from './icons';
import { Spinner } from './Spinner';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
  error: string | null;
  onSendMessage: (text: string) => void;
  hasFiles: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, error, onSendMessage, hasFiles }) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading && hasFiles) {
      onSendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="flex flex-col flex-1 bg-slate-800/50 overflow-hidden">
      <div className="flex-1 p-4 md:p-6 overflow-y-auto custom-scrollbar">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((msg, index) => (
            <div key={index} className={`flex items-start gap-4 ${msg.sender === MessageSender.USER ? 'justify-end' : 'justify-start'}`}>
              {msg.sender === MessageSender.AI && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <BrainCircuitIcon className="w-5 h-5 text-white" />
                </div>
              )}
              <div
                className={`max-w-xl p-4 rounded-xl shadow-md ${
                  msg.sender === MessageSender.USER
                    ? 'bg-blue-600 text-white rounded-br-none'
                    : 'bg-slate-700 text-slate-200 rounded-bl-none'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
              </div>
               {msg.sender === MessageSender.USER && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-slate-300" />
                </div>
              )}
            </div>
          ))}
          {isLoading && (
            <div className="flex items-start gap-4 justify-start">
               <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <BrainCircuitIcon className="w-5 h-5 text-white" />
                </div>
                <div className="max-w-xl p-4 rounded-xl shadow-md bg-slate-700 rounded-bl-none flex items-center">
                  <Spinner />
                  <span className="ml-3 text-slate-400 animate-pulse">Thinking...</span>
                </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="p-4 md:p-6 border-t border-slate-700 bg-slate-900">
        <div className="max-w-4xl mx-auto">
          {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
          <form onSubmit={handleSubmit} className="flex items-center gap-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={hasFiles ? "Ask a question about your documents..." : "Please upload a document first"}
              disabled={!hasFiles || isLoading}
              className="flex-1 p-3 bg-slate-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:outline-none transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <button
              type="submit"
              disabled={!hasFiles || isLoading}
              className="p-3 rounded-lg bg-cyan-500 hover:bg-cyan-600 text-white transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SendIcon className="w-6 h-6" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
