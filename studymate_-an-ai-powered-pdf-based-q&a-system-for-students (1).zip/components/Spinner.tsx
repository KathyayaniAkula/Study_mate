
import React from 'react';

export const Spinner: React.FC = () => {
  return (
    <div className="w-5 h-5 border-2 border-t-transparent border-slate-400 rounded-full animate-spin"></div>
  );
};
