
import React, { useRef } from 'react';
import type { UploadedFile } from '../types';
import { UploadCloudIcon, FileIcon, XIcon, Trash2Icon } from './icons';

interface FileUploaderProps {
  onFileChange: (files: FileList | null) => void;
  files: UploadedFile[];
  onClearFiles: () => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onFileChange, files, onClearFiles }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileChange(e.dataTransfer.files);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <label
        htmlFor="file-upload"
        className="relative block w-full p-6 text-center border-2 border-dashed rounded-lg cursor-pointer border-slate-600 hover:border-cyan-400 transition-colors duration-200 bg-slate-800"
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center justify-center">
          <UploadCloudIcon className="w-12 h-12 text-slate-400" />
          <p className="mt-2 text-sm text-slate-400">
            <span className="font-semibold text-cyan-400">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-slate-500">PDFs, DOCs, PNGs, JPGs, etc.</p>
        </div>
        <input
          id="file-upload"
          name="file-upload"
          type="file"
          multiple
          className="sr-only"
          ref={fileInputRef}
          onChange={(e) => onFileChange(e.target.files)}
        />
      </label>

      {files.length > 0 && (
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-semibold text-slate-300">Uploaded Documents ({files.length})</h3>
            <button
              onClick={onClearFiles}
              className="flex items-center text-xs text-red-400 hover:text-red-300 transition-colors"
            >
              <Trash2Icon className="w-4 h-4 mr-1"/>
              Clear All
            </button>
          </div>
          <ul className="flex flex-wrap gap-2">
            {files.map((file, index) => (
              <li
                key={index}
                className="flex items-center px-3 py-1 text-sm rounded-full bg-slate-700 text-slate-200"
              >
                <FileIcon className="w-4 h-4 mr-2 text-slate-400" />
                {file.name}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default FileUploader;
