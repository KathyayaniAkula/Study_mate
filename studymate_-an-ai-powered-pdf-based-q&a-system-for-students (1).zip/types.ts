
export interface UploadedFile {
  name: string;
  type: string;
  content: string; // base64 encoded content
}

export enum MessageSender {
  USER = 'user',
  AI = 'ai',
}

export interface ChatMessage {
  sender: MessageSender;
  text: string;
}
