
import { useState, useCallback } from 'react';
import type { UploadedFile, ChatMessage } from '../types';
import { MessageSender } from '../types';
import { analyzeDocuments } from '../services/geminiService';

export const useChat = () => {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((selectedFiles: FileList | null) => {
    if (!selectedFiles) return;

    setError(null);
    const newFiles: Promise<UploadedFile>[] = Array.from(selectedFiles).map(file => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (typeof event.target?.result === 'string') {
            const base64Content = event.target.result.split(',')[1];
            if (base64Content) {
              resolve({
                name: file.name,
                type: file.type,
                content: base64Content,
              });
            } else {
              reject(new Error('Failed to read file content.'));
            }
          }
        };
        reader.onerror = () => reject(new Error('Error reading file.'));
        reader.readAsDataURL(file);
      });
    });

    Promise.all(newFiles)
      .then(uploadedFiles => {
        setFiles(prevFiles => [...prevFiles, ...uploadedFiles]);
        setMessages([{
          sender: MessageSender.AI,
          text: `I've analyzed ${uploadedFiles.length} new document(s). What would you like to know?`,
        }]);
      })
      .catch(err => {
        console.error(err);
        setError('There was an error processing your files. Please try again.');
      });
  }, []);

  const clearFiles = useCallback(() => {
    setFiles([]);
    setMessages([]);
  }, []);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || files.length === 0) return;

    const userMessage: ChatMessage = { sender: MessageSender.USER, text };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const aiResponse = await analyzeDocuments(text, files);
      const aiMessage: ChatMessage = { sender: MessageSender.AI, text: aiResponse };
      setMessages(prev => [...prev, aiMessage]);
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Sorry, I couldn't get a response. ${errorMessage}`);
      setMessages(prev => [...prev, { sender: MessageSender.AI, text: `Sorry, an error occurred: ${errorMessage}` }]);
    } finally {
      setIsLoading(false);
    }
  }, [files]);

  return { files, messages, isLoading, error, handleFileChange, sendMessage, clearFiles };
};
