
import React from 'react';
import { useChat } from './hooks/useChat';
import FileUploader from './components/FileUploader';
import ChatWindow from './components/ChatWindow';
import { BrainCircuitIcon } from './components/icons';

const App: React.FC = () => {
  const {
    files,
    messages,
    isLoading,
    error,
    handleFileChange,
    sendMessage,
    clearFiles,
  } = useChat();

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-slate-100 font-sans">
      <header className="flex items-center p-4 border-b border-slate-700 bg-slate-800/50 backdrop-blur-sm">
        <BrainCircuitIcon className="h-8 w-8 text-cyan-400" />
        <h1 className="ml-3 text-2xl font-bold text-slate-200">DocuMind Q&A</h1>
      </header>
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="p-4 md:p-6 border-b border-slate-700">
          <FileUploader onFileChange={handleFileChange} files={files} onClearFiles={clearFiles} />
        </div>
        <ChatWindow 
          messages={messages} 
          isLoading={isLoading} 
          error={error} 
          onSendMessage={sendMessage}
          hasFiles={files.length > 0}
        />
      </main>
    </div>
  );
};

export default App;
